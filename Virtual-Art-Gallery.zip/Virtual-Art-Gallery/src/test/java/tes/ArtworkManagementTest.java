package tes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;

import com.hexaware.entity.Artwork; import com.hexaware.dao.IVirtualArtGallery; import com.hexaware.dao.VirtualArtGalleryImpl; import com.hexaware.exception.ArtworkNotFoundException;

public class ArtworkManagementTest {

    private IVirtualArtGallery artGallery;
    private Artwork testArtwork;

    @BeforeEach
    public void setUp() {
        artGallery = new VirtualArtGalleryImpl();

        testArtwork = new Artwork();
        testArtwork.setArtworkId(1001);
        testArtwork.setTitle("Test Artwork");
        testArtwork.setDescription("This is a test artwork for unit testing");
        testArtwork.setCreationDate(new Date());
        testArtwork.setMedium("Oil on Canvas");
        testArtwork.setImageURL("http://example.com/test.jpg");
        testArtwork.setArtworkId(101);
    }

    @AfterEach
    public void tearDown() {
        try {
            artGallery.removeArtwork(testArtwork.getArtworkId());
        } catch (ArtworkNotFoundException e) {
            // Ignore
        }
    }

    @Test
    public void testAddArtwork() {
        boolean result = artGallery.addArtwork(testArtwork);
        assertTrue(result);

        try {
            Artwork retrieved = artGallery.getArtworkById(testArtwork.getArtworkId());
            assertNotNull(retrieved);
            assertEquals(testArtwork.getArtworkId(), retrieved.getArtworkId());
            assertEquals(testArtwork.getTitle(), retrieved.getTitle());
            assertEquals(testArtwork.getDescription(), retrieved.getDescription());
        } catch (ArtworkNotFoundException e) {
            fail("Artwork should exist");
        }
    }

    @Test
    public void testUpdateArtwork() throws ArtworkNotFoundException {
        artGallery.addArtwork(testArtwork);

        testArtwork.setTitle("Updated Test Artwork");
        testArtwork.setDescription("Updated Description");
        testArtwork.setMedium("Acrylic on Canvas");

        boolean result = artGallery.updateArtwork(testArtwork);
        assertTrue(result);

        try {
            Artwork updated = artGallery.getArtworkById(testArtwork.getArtistId());
            assertEquals("Updated Test Artwork", updated.getTitle());
            assertEquals("Updated Description", updated.getDescription());
            assertEquals("Acrylic on Canvas", updated.getMedium());
        } catch (ArtworkNotFoundException e) {
            fail("Should not throw exception after update");
        }
    }

    @Test
    public void testRemoveArtwork() throws ArtworkNotFoundException {
        artGallery.addArtwork(testArtwork);

        boolean result = artGallery.removeArtwork(testArtwork.getArtistId());
        assertTrue(result);

        assertThrows(ArtworkNotFoundException.class, () -> {
            artGallery.getArtworkById(testArtwork.getArtistId());
        });
    }

    @Test
    public void testSearchArtworks() {
        Artwork artwork1 = new Artwork();
        artwork1.setArtworkId(2001);
        artwork1.setTitle("Landscape Sunrise");
        artwork1.setDescription("A beautiful sunrise over mountains");
        artwork1.setCreationDate(new Date());
        artwork1.setArtistId(201);
        artGallery.addArtwork(artwork1);

        Artwork artwork2 = new Artwork();
        artwork2.setArtworkId(2002);
        artwork2.setTitle("Portrait of Lady");
        artwork2.setDescription("A portrait with landscape background");
        artwork2.setCreationDate(new Date());
        artwork2.setArtistId(202);
        artGallery.addArtwork(artwork2);

        Artwork artwork3 = new Artwork();
        artwork3.setArtworkId(2003);
        artwork3.setTitle("Abstract Art");
        artwork3.setDescription("Modern abstract composition");
        artwork3.setCreationDate(new Date());
        artwork3.setArtistId(203);
        artGallery.addArtwork(artwork3);

        List<Artwork> results = artGallery.searchArtworks("landscape");
        assertNotNull(results);
        assertEquals(2, results.size());

        boolean found1 = false, found2 = false, found3 = false;
        for (Artwork a : results) {
            if (a.getArtworkId() == 2001) found1 = true;
            if (a.getArtworkId() == 2002) found2 = true;
            if (a.getArtworkId() == 2003) found3 = true;
        }

        assertTrue(found1);
        assertTrue(found2);
        assertFalse(found3);

        try {
            artGallery.removeArtwork(2001);
            artGallery.removeArtwork(2002);
            artGallery.removeArtwork(2003);
        } catch (ArtworkNotFoundException e) {
            fail("Cleanup failed");
        }
    }

    @Test
    public void testGetArtworkByIdNotFound() {
        assertThrows(ArtworkNotFoundException.class, () -> {
            artGallery.getArtworkById(9999);
        });
    }
}